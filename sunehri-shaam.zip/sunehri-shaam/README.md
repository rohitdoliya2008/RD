# Sunehri Shaam — Rajasthani Folk Radio

A single-page nostalgia radio site: 50 Rajasthani folk tracks, a bottom-anchored
glass player, a live clock, a simulated listener count, and a dusk-fort backdrop
that swaps for orientation.

## Stack

Next.js (App Router) · TypeScript · Tailwind CSS v4 (theme tokens in
`app/globals.css`, no `tailwind.config`) · `@vercel/analytics` ·
`@vercel/speed-insights`. No CSS-in-JS, no component library, no state
manager — playback state lives in `Player.tsx` via `useState`/`useRef`.

## Setup

```bash
npm install
npm run dev
```

## Assets you need to provide

Nothing will render/play correctly out of the box — this is a code
scaffold, not a media library:

1. **Background images** — `public/bg/scene-wide.png` and
   `public/bg/scene-tall.png` (see the README in that folder). Portrait is
   swapped in via a CSS orientation media query, not a JS check.
2. **Audio files** — one mp3 per track in `public/audio/`, named to match
   the `slug` in `data/songs.ts` (see that folder's README for the naming
   rule + examples).
3. **Cover art (optional)** — the vinyl "label" is generated in CSS per
   track so the player works with zero image assets. Real artwork can be
   swapped in later; see `public/covers/README.md`.

## Structure

```
app/
  layout.tsx        fonts, metadata, viewport-fit: cover, Analytics/SpeedInsights
  page.tsx           server component, assembles the four fixed layers
  globals.css        Tailwind v4 import + @theme tokens + .hero-bg swap + keyframes
components/
  HeroBackground.tsx fixed bg image (-z-20) + gradient scrim
  GrainOverlay.tsx    fixed feTurbulence grain (-z-18)
  TopRow.tsx          3-col grid: clock / listener count / social links
  Clock.tsx           live clock (client)
  ListenerCount.tsx   simulated live count around 30.5K (client)
  SocialLinks.tsx     icon links
  player/
    Player.tsx         audio element + playback state; desktop pill + mobile card
    Vinyl.tsx           spinning record, generated label art, spindle hole
    SeekBar.tsx         24px hit area / 3px rail / accent glow / hover-only knob
    Transport.tsx       prev / play-pause / next
    utils.ts            glass class, time formatter, label colour hash
data/
  songs.ts            all 50 tracks, slugified for audio paths
  types.ts
```

## Notes on a couple of judgment calls

- **Artists**: most of these are traditions, not credited performers, so
  `data/songs.ts` tags each track by lineage (e.g. "Meera Bai," "Wedding
  Folk," "Traditional Rajasthani Folk") rather than inventing a fake name.
- **Mobile player layout**: the brief specified the desktop pill in full
  but was cut off before the mobile card. I built the stacked card
  (`sm:hidden` block in `Player.tsx`) using the same glass recipe, type
  scale, and control set as the desktop pill — cover + title/artist row,
  then seek bar, then centered transport. Easy to restyle if you had
  something more specific in mind.
- **Palette**: pulled from the reference photo (marigold accent, maroon +
  dusk-indigo, sandstone) rather than a generic AI-default palette — see
  the comment at the top of `app/globals.css`.
