Drop your two background images here, named exactly:

- scene-wide.png  (landscape — used by default)
- scene-tall.png  (portrait — swapped in via `@media (orientation: portrait)` in app/globals.css)

These should be separately composed, not crops of each other — see app/globals.css `.hero-bg`.
