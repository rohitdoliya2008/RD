No audio ships with this repo. The player expects one mp3 per track at:

  public/audio/{slug}.mp3

Slugs are generated from the titles in data/songs.ts (kebab-case). For example:

  Kesariya Balam Aavo Ni, Padharo Mhare Des
    -> public/audio/kesariya-balam-aavo-ni-padharo-mhare-des.mp3

  Meera Ke Pad
    -> public/audio/meera-ke-pad.mp3

Open data/songs.ts — every entry's `src` field is the exact path it expects.

Until files are added, the transport UI works but playback will fail silently
per track (the browser just can't load a missing file).
